var arrNumInitial=[1,2,45,-64,45,-1,4,6,53,12,-2,0,56];

document.write('Изначальный массив: ');
document.write(arrNumInitial+'</br>');
// 1.	В массиве чисел посчитать количество положительных и количество 
// отрицательных элементов. 
var arrNum=arrNumInitial;
var arrPositiveNum = arrNum.filter(function(value){
	return value>=0
});
var arrNegativeNum = arrNum.filter(function(value){
	return value<0
});
document.write('Количество положительных чисел: ');
document.write(arrPositiveNum.length+'</br>');
document.write('Количество отрицательных чисел: ');
document.write(arrNegativeNum.length+'</br>');

// 2.	Найти максимальный и минимальный элемент численного массива.
arrNum.sort(function(a,b){
	return a-b
});
document.write('Максимальное значение: ');
document.write(arrNum[arrNum.length-1]+'</br>');
document.write('Минимальное значение: ');
document.write(arrNum[0]+'</br>');


// 3.	Найти максимальный/минимальный по модулю элемент массива.
arrNum.sort(function(a,b){
	return a*a-b*b
});
document.write('Максимальное значение: ');
document.write(arrNum[arrNum.length-1]+'</br>');
document.write('Минимальное значение: ');
document.write(arrNum[0]+'</br>');

// 4.	Определить количество элементов массива, значение которых больше 
// соседних элементов
var biggerThanNeighbor = arrNum.reduce(function(result,value,i,arr){
	if(i!=0 || i!=arr.length-1){
		if(value >arr[i-1] && value < arr[i+1]){
			return result+1;
		}
	}
},0);
document.write('Количество эллементов, которые больше чем соседние: ');
document.write(biggerThanNeighbor+'</br>');

// 5.	Определить количество одинаковых элементов в массиве. 

// 6.	Заменить все элементы массива на противоположные по знаку.
var arrReverseSign = arrNum.map(function(value){return -value});
document.write('Изначальный массив: ');
document.write(arrNum+'</br>');
document.write('Массив - значения с противоположным знаком: ');
document.write(arrReverseSign+'</br>');
// 7.	Найти индекс и значение первого и последнего положительного элемента массива.
document.write('Индекс первого положительного элемента : ');
document.write(arrNum.findIndex(function(value){return value>0})+'</br>');
document.write('Индекс последнего положительного элемента : ');
document.write(arrNum.length-1-arrNum.reverse().findIndex(function(value){return value>0})+'</br>');
arrNum=arrNumInitial;
// 8.	Найти среднее арифметическое чисел в массиве.
var arrSum = arrNum.reduce(function(result,value) {
	return result +value;
},0);
document.write('Среднее арифметическое число в массиве : ');
document.write(arrSum/arrNum.length+'</br>');

// 9.	Отсортировать числовой массив по убыванию/возрастанию. 
arrNum.sort(function(a,b){
	return b-a
});
document.write('Массив по убыванию: ');
document.write(arrNum+'</br>');

arrNum.sort(function(a,b){
	return a-b
});
document.write('Массив по возрастанию: ');
document.write(arrNum+'</br>');

arrNum=arrNumInitial;

// 10.	Определить количество отрицательных и положительных элементов массива.

// 11.	Вводится с клавиатуры текст в виде массива слов. Определить слово максимальной длины.
// 12.	Найти количество палиндромов в массиве слов.
// 13.	Отфильтровать смешанный массив так, чтобы среди элементов массива остались только слова.
// 14.	Перевернуть каждое слово в массиве. (холод -> долох, шаг -> гаш).
// 15.	Написать функцию для объединения двух массивов, при этом все копии элементов удаляются.
